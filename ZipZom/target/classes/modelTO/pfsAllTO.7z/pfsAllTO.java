package modelTO;

public class pfsAllTO {
	private int seqPfs;
	private String bType;
	private String address;
	private String hNumber;
	private String dong;
	private String contractType;
	private int budget1;
	private int budget2;
	private int budget3;
	private String loan;
	private int area1;
	private int area2;
	private int area3;
	private String moveSchedule;
	private String endOfLease;
	private int room;
	private int bathroom;
	private String direction;
	private String heatingSystem;
	private int aircondition;
	private int numberOfHousehold;
	private int parking;
	private int floor;
	private int floorTotal;
	private int elevator;
	private String bYear;
	private String context;
	private int securityGuard;
	private int videophone;
	private int interphone;
	private int cardKey;
	private int cctv;
	private int doorSecurity;
	private int windowGuard;
	private String lessorName;
	private String lessorTel;
	private String lesseeName;
	private String lesseeTel;
	
	public String getDong() {
		return dong;
	}
	public void setDong(String dong) {
		this.dong = dong;
	}
	public String gethNumber() {
		return hNumber;
	}
	public void sethNumber(String hNumber) {
		this.hNumber = hNumber;
	}
	public int getSeqPfs() {
		return seqPfs;
	}
	public void setSeqPfs(int seqPfs) {
		this.seqPfs = seqPfs;
	}
	public String getbType() {
		return bType;
	}
	public void setbType(String bType) {
		this.bType = bType;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public int getBudget1() {
		return budget1;
	}
	public void setBudget1(int budget1) {
		this.budget1 = budget1;
	}
	public int getBudget2() {
		return budget2;
	}
	public void setBudget2(int budget2) {
		this.budget2 = budget2;
	}
	public int getBudget3() {
		return budget3;
	}
	public void setBudget3(int budget3) {
		this.budget3 = budget3;
	}
	public String getLoan() {
		return loan;
	}
	public void setLoan(String loan) {
		this.loan = loan;
	}
	public int getArea1() {
		return area1;
	}
	public void setArea1(int area1) {
		this.area1 = area1;
	}
	public int getArea2() {
		return area2;
	}
	public void setArea2(int area2) {
		this.area2 = area2;
	}
	public int getArea3() {
		return area3;
	}
	public void setArea3(int area3) {
		this.area3 = area3;
	}
	public String getMoveSchedule() {
		return moveSchedule;
	}
	public void setMoveSchedule(String moveSchedule) {
		this.moveSchedule = moveSchedule;
	}
	public String getEndOfLease() {
		return endOfLease;
	}
	public void setEndOfLease(String endOfLease) {
		this.endOfLease = endOfLease;
	}
	public int getRoom() {
		return room;
	}
	public void setRoom(int room) {
		this.room = room;
	}
	public int getBathroom() {
		return bathroom;
	}
	public void setBathroom(int bathroom) {
		this.bathroom = bathroom;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getHeatingSystem() {
		return heatingSystem;
	}
	public void setHeatingSystem(String heatingSystem) {
		this.heatingSystem = heatingSystem;
	}
	public int getAircondition() {
		return aircondition;
	}
	public void setAircondition(int aircondition) {
		this.aircondition = aircondition;
	}
	public int getNumberOfHousehold() {
		return numberOfHousehold;
	}
	public void setNumberOfHousehold(int numberOfHousehold) {
		this.numberOfHousehold = numberOfHousehold;
	}
	public int getParking() {
		return parking;
	}
	public void setParking(int parking) {
		this.parking = parking;
	}
	public int getFloor() {
		return floor;
	}
	public void setFloor(int floor) {
		this.floor = floor;
	}
	public int getFloorTotal() {
		return floorTotal;
	}
	public void setFloorTotal(int floorTotal) {
		this.floorTotal = floorTotal;
	}

	public int getElevator() {
		return elevator;
	}
	public void setElevator(int elevator) {
		this.elevator = elevator;
	}
	public String getbYear() {
		return bYear;
	}
	public void setbYear(String bYear) {
		this.bYear = bYear;
	}
	public String getContext() {
		return context;
	}
	public void setContext(String context) {
		this.context = context;
	}
	public String getLessorName() {
		return lessorName;
	}
	public void setLessorName(String lessorName) {
		this.lessorName = lessorName;
	}
	public String getLessorTel() {
		return lessorTel;
	}
	public void setLessorTel(String lessorTel) {
		this.lessorTel = lessorTel;
	}
	public String getLesseeName() {
		return lesseeName;
	}
	public void setLesseeName(String lesseeName) {
		this.lesseeName = lesseeName;
	}
	public String getLesseeTel() {
		return lesseeTel;
	}
	public void setLesseeTel(String lesseeTel) {
		this.lesseeTel = lesseeTel;
	}
	public int getSecurityGuard() {
		return securityGuard;
	}
	public void setSecurityGuard(int securityGuard) {
		this.securityGuard = securityGuard;
	}
	public int getVideophone() {
		return videophone;
	}
	public void setVideophone(int videophone) {
		this.videophone = videophone;
	}
	public int getInterphone() {
		return interphone;
	}
	public void setInterphone(int interphone) {
		this.interphone = interphone;
	}
	public int getCardKey() {
		return cardKey;
	}
	public void setCardKey(int cardKey) {
		this.cardKey = cardKey;
	}
	public int getCctv() {
		return cctv;
	}
	public void setCctv(int cctv) {
		this.cctv = cctv;
	}
	public int getDoorSecurity() {
		return doorSecurity;
	}
	public void setDoorSecurity(int doorSecurity) {
		this.doorSecurity = doorSecurity;
	}
	public int getWindowGuard() {
		return windowGuard;
	}
	public void setWindowGuard(int windowGuard) {
		this.windowGuard = windowGuard;
	}
	
	

}
