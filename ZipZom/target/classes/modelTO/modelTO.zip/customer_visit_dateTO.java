package modelTO;

public class customer_visit_dateTO {
	private int seqCvd;
	private int pseqCvd;
	private String visitDate;
	
	public int getSeqCvd() {
		return seqCvd;
	}
	public void setSeqCvd(int seqCvd) {
		this.seqCvd = seqCvd;
	}
	public int getPseqCvd() {
		return pseqCvd;
	}
	public void setPseqCvd(int pseqCvd) {
		this.pseqCvd = pseqCvd;
	}
	public String getVisitDate() {
		return visitDate;
	}
	public void setVisitDate(String visitDate) {
		this.visitDate = visitDate;
	}
	
	
}
