package modelTO;

public class security_customerTO {
	private int seqSc;
	private int pseqSc;
	private boolean securityGuard;
	private boolean videophone;
	private boolean interphone;
	private boolean cardKey;
	private boolean cctv;
	private boolean doorSecurity;
	private boolean windowGuard;
	
	public int getSeqSc() {
		return seqSc;
	}
	public void setSeqSc(int seqSc) {
		this.seqSc = seqSc;
	}
	public int getPseqSc() {
		return pseqSc;
	}
	public void setPseqSc(int pseqSc) {
		this.pseqSc = pseqSc;
	}
	public boolean isSecurityGuard() {
		return securityGuard;
	}
	public void setSecurityGuard(boolean securityGuard) {
		this.securityGuard = securityGuard;
	}
	public boolean isVideophone() {
		return videophone;
	}
	public void setVideophone(boolean videophone) {
		this.videophone = videophone;
	}
	public boolean isInterphone() {
		return interphone;
	}
	public void setInterphone(boolean interphone) {
		this.interphone = interphone;
	}
	public boolean isCardKey() {
		return cardKey;
	}
	public void setCardKey(boolean cardKey) {
		this.cardKey = cardKey;
	}
	public boolean isCctv() {
		return cctv;
	}
	public void setCctv(boolean cctv) {
		this.cctv = cctv;
	}
	public boolean isDoorSecurity() {
		return doorSecurity;
	}
	public void setDoorSecurity(boolean doorSecurity) {
		this.doorSecurity = doorSecurity;
	}
	public boolean isWindowGuard() {
		return windowGuard;
	}
	public void setWindowGuard(boolean windowGuard) {
		this.windowGuard = windowGuard;
	}
	
}
