package modelTO;

public class rtpTO {
	// REAL TRANSACTION PRICE
	private int seqRtp;
	private int pseqRtp;
	private String si;
	private String gu;
	private String dong;
	private String bunji;
	private String bName;
	private int area2;
	private String contractDate1;
	private String contractDate2;
	private int price;
	private int floor;
	private int bYear;
	private String roadAddress;
	
	public int getSeqRtp() {
		return seqRtp;
	}
	public void setSeqRtp(int seqRtp) {
		this.seqRtp = seqRtp;
	}
	public int getPseqRtp() {
		return pseqRtp;
	}
	public void setPseqRtp(int pseqRtp) {
		this.pseqRtp = pseqRtp;
	}
	public String getSi() {
		return si;
	}
	public void setSi(String si) {
		this.si = si;
	}
	public String getGu() {
		return gu;
	}
	public void setGu(String gu) {
		this.gu = gu;
	}
	public String getDong() {
		return dong;
	}
	public void setDong(String dong) {
		this.dong = dong;
	}
	public String getBunji() {
		return bunji;
	}
	public void setBunji(String bunji) {
		this.bunji = bunji;
	}
	public String getbName() {
		return bName;
	}
	public void setbName(String bName) {
		this.bName = bName;
	}
	public int getArea2() {
		return area2;
	}
	public void setArea2(int area2) {
		this.area2 = area2;
	}
	public String getContractDate1() {
		return contractDate1;
	}
	public void setContractDate1(String contractDate1) {
		this.contractDate1 = contractDate1;
	}
	public String getContractDate2() {
		return contractDate2;
	}
	public void setContractDate2(String contractDate2) {
		this.contractDate2 = contractDate2;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getFloor() {
		return floor;
	}
	public void setFloor(int floor) {
		this.floor = floor;
	}
	public int getbYear() {
		return bYear;
	}
	public void setbYear(int bYear) {
		this.bYear = bYear;
	}
	public String getRoadAddress() {
		return roadAddress;
	}
	public void setRoadAddress(String roadAddress) {
		this.roadAddress = roadAddress;
	}
	
	
}
