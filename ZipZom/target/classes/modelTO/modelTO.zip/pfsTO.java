package modelTO;

public class pfsTO {
	// PROPERTY FOR SALE
	private int seqPfs;
	private int pseqPfs;
	private boolean images;
	private String bType;
	private String si;
	private String gu;
	private String dong;
	private String bunji;
	private int hNumber;
	private String contractType;
	private int budget1;
	private int budget2;
	private int budget3;
	private int budget4;
	private int budget5;
	private int budget6;
	private int mCost;
	private int loan;
	private int area1;
	private int area2;
	private int area3;
	private String moveSchedule;
	private String endOfLease;
	private int room;
	private int bathroom;
	private String direction;
	private String heatingSystem;
	private boolean aircondition;
	private boolean option;
	private int numberOfHousehold;
	private int parking;
	private int floor;
	private int floorTotal;
	private boolean elevator;
	private String bYear;
	private String context;
	private boolean security;
	private String lessorName;
	private String lessorTel;
	private String lesseeName;
	private String lesseeTel;
	
	public int getSeqPfs() {
		return seqPfs;
	}
	public void setSeqPfs(int seqPfs) {
		this.seqPfs = seqPfs;
	}
	public int getPseqPfs() {
		return pseqPfs;
	}
	public void setPseqPfs(int pseqPfs) {
		this.pseqPfs = pseqPfs;
	}
	public boolean isImages() {
		return images;
	}
	public void setImages(boolean images) {
		this.images = images;
	}
	public String getbType() {
		return bType;
	}
	public void setbType(String bType) {
		this.bType = bType;
	}
	public String getSi() {
		return si;
	}
	public void setSi(String si) {
		this.si = si;
	}
	public String getGu() {
		return gu;
	}
	public void setGu(String gu) {
		this.gu = gu;
	}
	public String getDong() {
		return dong;
	}
	public void setDong(String dong) {
		this.dong = dong;
	}
	public String getBunji() {
		return bunji;
	}
	public void setBunji(String bunji) {
		this.bunji = bunji;
	}
	public int gethNumber() {
		return hNumber;
	}
	public void sethNumber(int hNumber) {
		this.hNumber = hNumber;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public int getBudget1() {
		return budget1;
	}
	public void setBudget1(int budget1) {
		this.budget1 = budget1;
	}
	public int getBudget2() {
		return budget2;
	}
	public void setBudget2(int budget2) {
		this.budget2 = budget2;
	}
	public int getBudget3() {
		return budget3;
	}
	public void setBudget3(int budget3) {
		this.budget3 = budget3;
	}
	public int getBudget4() {
		return budget4;
	}
	public void setBudget4(int budget4) {
		this.budget4 = budget4;
	}
	public int getBudget5() {
		return budget5;
	}
	public void setBudget5(int budget5) {
		this.budget5 = budget5;
	}
	public int getBudget6() {
		return budget6;
	}
	public void setBudget6(int budget6) {
		this.budget6 = budget6;
	}
	public int getmCost() {
		return mCost;
	}
	public void setmCost(int mCost) {
		this.mCost = mCost;
	}
	public int getLoan() {
		return loan;
	}
	public void setLoan(int loan) {
		this.loan = loan;
	}
	public int getArea1() {
		return area1;
	}
	public void setArea1(int area1) {
		this.area1 = area1;
	}
	public int getArea2() {
		return area2;
	}
	public void setArea2(int area2) {
		this.area2 = area2;
	}
	public int getArea3() {
		return area3;
	}
	public void setArea3(int area3) {
		this.area3 = area3;
	}
	public String getMoveSchedule() {
		return moveSchedule;
	}
	public void setMoveSchedule(String moveSchedule) {
		this.moveSchedule = moveSchedule;
	}
	public String getEndOfLease() {
		return endOfLease;
	}
	public void setEndOfLease(String endOfLease) {
		this.endOfLease = endOfLease;
	}
	public int getRoom() {
		return room;
	}
	public void setRoom(int room) {
		this.room = room;
	}
	public int getBathroom() {
		return bathroom;
	}
	public void setBathroom(int bathroom) {
		this.bathroom = bathroom;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getHeatingSystem() {
		return heatingSystem;
	}
	public void setHeatingSystem(String heatingSystem) {
		this.heatingSystem = heatingSystem;
	}
	public boolean isAircondition() {
		return aircondition;
	}
	public void setAircondition(boolean aircondition) {
		this.aircondition = aircondition;
	}
	public boolean isOption() {
		return option;
	}
	public void setOption(boolean option) {
		this.option = option;
	}
	public int getNumberOfHousehold() {
		return numberOfHousehold;
	}
	public void setNumberOfHousehold(int numberOfHousehold) {
		this.numberOfHousehold = numberOfHousehold;
	}
	public int getParking() {
		return parking;
	}
	public void setParking(int parking) {
		this.parking = parking;
	}
	public int getFloor() {
		return floor;
	}
	public void setFloor(int floor) {
		this.floor = floor;
	}
	public int getFloorTotal() {
		return floorTotal;
	}
	public void setFloorTotal(int floorTotal) {
		this.floorTotal = floorTotal;
	}
	public boolean isElevator() {
		return elevator;
	}
	public void setElevator(boolean elevator) {
		this.elevator = elevator;
	}
	public String getbYear() {
		return bYear;
	}
	public void setbYear(String bYear) {
		this.bYear = bYear;
	}
	public String getContext() {
		return context;
	}
	public void setContext(String context) {
		this.context = context;
	}
	public boolean isSecurity() {
		return security;
	}
	public void setSecurity(boolean security) {
		this.security = security;
	}
	public String getLessorName() {
		return lessorName;
	}
	public void setLessorName(String lessorName) {
		this.lessorName = lessorName;
	}
	public String getLessorTel() {
		return lessorTel;
	}
	public void setLessorTel(String lessorTel) {
		this.lessorTel = lessorTel;
	}
	public String getLesseeName() {
		return lesseeName;
	}
	public void setLesseeName(String lesseeName) {
		this.lesseeName = lesseeName;
	}
	public String getLesseeTel() {
		return lesseeTel;
	}
	public void setLesseeTel(String lesseeTel) {
		this.lesseeTel = lesseeTel;
	}
	
	
}
