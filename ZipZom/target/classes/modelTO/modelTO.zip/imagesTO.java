package modelTO;

public class imagesTO {
	private int seqI;
	private int pseqI;
	private String imageName;
	
	public int getSeqI() {
		return seqI;
	}
	public void setSeqI(int seqI) {
		this.seqI = seqI;
	}
	public int getPseqI() {
		return pseqI;
	}
	public void setPseqI(int pseqI) {
		this.pseqI = pseqI;
	}
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	
	
}
