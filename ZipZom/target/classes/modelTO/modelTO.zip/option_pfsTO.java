package modelTO;

public class option_pfsTO {
	private int seqOp;
	private int pseqOp;
	private boolean bed;
	private boolean washingMachine;
	private boolean desc;
	private boolean dryingMachine;
	private boolean induction;
	private boolean electricRange;
	private boolean gasRange;
	private boolean wordrobe;
	private boolean sink;
	private boolean shoeRack;
	private boolean refrigerator;
	private boolean bathTube;
	
	public int getSeqOp() {
		return seqOp;
	}
	public void setSeqOp(int seqOp) {
		this.seqOp = seqOp;
	}
	public int getPseqOp() {
		return pseqOp;
	}
	public void setPseqOp(int pseqOp) {
		this.pseqOp = pseqOp;
	}
	public boolean isBed() {
		return bed;
	}
	public void setBed(boolean bed) {
		this.bed = bed;
	}
	public boolean isWashingMachine() {
		return washingMachine;
	}
	public void setWashingMachine(boolean washingMachine) {
		this.washingMachine = washingMachine;
	}
	public boolean isDesc() {
		return desc;
	}
	public void setDesc(boolean desc) {
		this.desc = desc;
	}
	public boolean isDryingMachine() {
		return dryingMachine;
	}
	public void setDryingMachine(boolean dryingMachine) {
		this.dryingMachine = dryingMachine;
	}
	public boolean isInduction() {
		return induction;
	}
	public void setInduction(boolean induction) {
		this.induction = induction;
	}
	public boolean isElectricRange() {
		return electricRange;
	}
	public void setElectricRange(boolean electricRange) {
		this.electricRange = electricRange;
	}
	public boolean isGasRange() {
		return gasRange;
	}
	public void setGasRange(boolean gasRange) {
		this.gasRange = gasRange;
	}
	public boolean isWordrobe() {
		return wordrobe;
	}
	public void setWordrobe(boolean wordrobe) {
		this.wordrobe = wordrobe;
	}
	public boolean isSink() {
		return sink;
	}
	public void setSink(boolean sink) {
		this.sink = sink;
	}
	public boolean isShoeRack() {
		return shoeRack;
	}
	public void setShoeRack(boolean shoeRack) {
		this.shoeRack = shoeRack;
	}
	public boolean isRefrigerator() {
		return refrigerator;
	}
	public void setRefrigerator(boolean refrigerator) {
		this.refrigerator = refrigerator;
	}
	public boolean isBathTube() {
		return bathTube;
	}
	public void setBathTube(boolean bathTube) {
		this.bathTube = bathTube;
	}
	
}
