package modelTO;

public class customer_selecthouseTO {
	private int seqCs;
	private int pseqCs;
	private int selectHouse;
	
	public int getSeqCs() {
		return seqCs;
	}
	public void setSeqCs(int seqCs) {
		this.seqCs = seqCs;
	}
	public int getPseqCs() {
		return pseqCs;
	}
	public void setPseqCs(int pseqCs) {
		this.pseqCs = pseqCs;
	}
	public int getSelectHouse() {
		return selectHouse;
	}
	public void setSelectHouse(int selectHouse) {
		this.selectHouse = selectHouse;
	}
	
	
}
