package modelTO;

public class scheduleTO {
	private int seqS;
	private int pseqS;
	private int cseq;
	private String date;
	private String context;
	private String scheduleType;
	private String progress;
	private String bType;
	private String contractType;
	
	public int getSeqS() {
		return seqS;
	}
	public void setSeqS(int seqS) {
		this.seqS = seqS;
	}
	public int getPseqS() {
		return pseqS;
	}
	public void setPseqS(int pseqS) {
		this.pseqS = pseqS;
	}
	public int getCseq() {
		return cseq;
	}
	public void setCseq(int cseq) {
		this.cseq = cseq;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getContext() {
		return context;
	}
	public void setContext(String context) {
		this.context = context;
	}
	public String getScheduleType() {
		return scheduleType;
	}
	public void setScheduleType(String scheduleType) {
		this.scheduleType = scheduleType;
	}
	public String getProgress() {
		return progress;
	}
	public void setProgress(String progress) {
		this.progress = progress;
	}
	public String getbType() {
		return bType;
	}
	public void setbType(String bType) {
		this.bType = bType;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	
}
