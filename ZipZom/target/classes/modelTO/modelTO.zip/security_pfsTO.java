package modelTO;

public class security_pfsTO {
	private int seqSp;
	private int pseqSp;
	private boolean securityGuard;
	private boolean videophone;
	private boolean interphone;
	private boolean cardKey;
	private boolean cctv;
	private boolean doorSecurity;
	private boolean windowGuard;
	
	public int getSeqSp() {
		return seqSp;
	}
	public void setSeqSp(int seqSp) {
		this.seqSp = seqSp;
	}
	public int getPseqSp() {
		return pseqSp;
	}
	public void setPseqSp(int pseqSp) {
		this.pseqSp = pseqSp;
	}
	public boolean isSecurityGuard() {
		return securityGuard;
	}
	public void setSecurityGuard(boolean securityGuard) {
		this.securityGuard = securityGuard;
	}
	public boolean isVideophone() {
		return videophone;
	}
	public void setVideophone(boolean videophone) {
		this.videophone = videophone;
	}
	public boolean isInterphone() {
		return interphone;
	}
	public void setInterphone(boolean interphone) {
		this.interphone = interphone;
	}
	public boolean isCardKey() {
		return cardKey;
	}
	public void setCardKey(boolean cardKey) {
		this.cardKey = cardKey;
	}
	public boolean isCctv() {
		return cctv;
	}
	public void setCctv(boolean cctv) {
		this.cctv = cctv;
	}
	public boolean isDoorSecurity() {
		return doorSecurity;
	}
	public void setDoorSecurity(boolean doorSecurity) {
		this.doorSecurity = doorSecurity;
	}
	public boolean isWindowGuard() {
		return windowGuard;
	}
	public void setWindowGuard(boolean windowGuard) {
		this.windowGuard = windowGuard;
	}
	
}
