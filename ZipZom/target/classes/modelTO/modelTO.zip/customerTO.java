package modelTO;

public class customerTO {
	private int seqC;
	private int pseqC;
	private String name;
	private String tel;
	private String type;
	private String progress;
	private String contractType;
	private int budgetT1;
	private int budgetT2;
	private int budgetT3;
	private int budgetl;
	private int budgetM1;
	private int budgetM2;
	private int area2;
	private String moveSchedule;
	private int room;
	private String direction;
	private boolean option;
	private int floor;
	private boolean elevator;
	private String bYear;
	private String context;
	private boolean security;
	public int getSeqC() {
		return seqC;
	}
	public void setSeqC(int seqC) {
		this.seqC = seqC;
	}
	public int getPseqC() {
		return pseqC;
	}
	public void setPseqC(int pseqC) {
		this.pseqC = pseqC;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getProgress() {
		return progress;
	}
	public void setProgress(String progress) {
		this.progress = progress;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public int getBudgetT1() {
		return budgetT1;
	}
	public void setBudgetT1(int budgetT1) {
		this.budgetT1 = budgetT1;
	}
	public int getBudgetT2() {
		return budgetT2;
	}
	public void setBudgetT2(int budgetT2) {
		this.budgetT2 = budgetT2;
	}
	public int getBudgetT3() {
		return budgetT3;
	}
	public void setBudgetT3(int budgetT3) {
		this.budgetT3 = budgetT3;
	}
	public int getBudgetl() {
		return budgetl;
	}
	public void setBudgetl(int budgetl) {
		this.budgetl = budgetl;
	}
	public int getBudgetM1() {
		return budgetM1;
	}
	public void setBudgetM1(int budgetM1) {
		this.budgetM1 = budgetM1;
	}
	public int getBudgetM2() {
		return budgetM2;
	}
	public void setBudgetM2(int budgetM2) {
		this.budgetM2 = budgetM2;
	}
	public int getArea2() {
		return area2;
	}
	public void setArea2(int area2) {
		this.area2 = area2;
	}
	public String getMoveSchedule() {
		return moveSchedule;
	}
	public void setMoveSchedule(String moveSchedule) {
		this.moveSchedule = moveSchedule;
	}
	public int getRoom() {
		return room;
	}
	public void setRoom(int room) {
		this.room = room;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public boolean isOption() {
		return option;
	}
	public void setOption(boolean option) {
		this.option = option;
	}
	public int getFloor() {
		return floor;
	}
	public void setFloor(int floor) {
		this.floor = floor;
	}
	public boolean isElevator() {
		return elevator;
	}
	public void setElevator(boolean elevator) {
		this.elevator = elevator;
	}
	public String getbYear() {
		return bYear;
	}
	public void setbYear(String bYear) {
		this.bYear = bYear;
	}
	public String getContext() {
		return context;
	}
	public void setContext(String context) {
		this.context = context;
	}
	public boolean isSecurity() {
		return security;
	}
	public void setSecurity(boolean security) {
		this.security = security;
	}
	
	
}
